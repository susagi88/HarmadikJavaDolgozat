package orabolt;

public class FelsorolasOsztaly{
	
	public enum OraTipus {
		
		KARORA("karóra"), FALIORA("falióra"), STOPPER("stopperóra"), EBRESZTOORA("ébresztőóra");
		
		private final String tipusMegnevezes;
		
		private OraTipus(String tipusMegnevezes) {
			this.tipusMegnevezes=tipusMegnevezes;
		}
		
		public String toString() {
			return tipusMegnevezes;
		}
		
		public static OraTipus tipusKonvert(String megnevezes) {
			for(OraTipus tipus : OraTipus.values()) {
				if(tipus.tipusMegnevezes.equals(megnevezes)) {
					return tipus;
				}
			}
			
			throw new IllegalArgumentException("Nem létező felsorolás típus!");
		}

	}
	
}


