package orabolt;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import orabolt.FelsorolasOsztaly.OraTipus;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JComboBox;
import java.awt.Color;



public class OraboltFoprogram {

	private JFrame frmOrabolt;
	private List<Ora> orak= new ArrayList<Ora>();
	private DefaultListModel<Object> listModel;
	private JList<Object> listTermekek;
	private JTextField textAr;
	private JTextField textMegnevezes;
	private JCheckBox cbVizallo;
	private Ora oraObj;
	private JTextField textTipus;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OraboltFoprogram window = new OraboltFoprogram();
					window.frmOrabolt.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OraboltFoprogram() {
		initialize();
		try {
			ABKezelo.csatlakozas();
			
			orak=ABKezelo.orakBeolvasasa();
			
			listModel = new DefaultListModel<>();
			listaHozzarendeleseModellhez();
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmOrabolt = new JFrame();
		frmOrabolt.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Object[] opciok = {"Igen", "Nem"};
				
				if(JOptionPane.showOptionDialog(frmOrabolt, "Biztosan kilép?", "Kilépés", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,null, opciok, opciok[1])==JOptionPane.YES_OPTION) {
					
					try {
						ABKezelo.kapcsolatBontas();
						
					} catch (SQLException e2) {
						JOptionPane.showMessageDialog(frmOrabolt, e2.getMessage(), "DB hiba!", JOptionPane.ERROR_MESSAGE);
						System.exit(1);
					}
					System.exit(0);
				}
			}
		});
		frmOrabolt.setTitle("Órabolt");
		frmOrabolt.setBounds(100, 100, 673, 474);
		frmOrabolt.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frmOrabolt.getContentPane().setLayout(null);
		
		JLabel lblMegnevezes = new JLabel("Megnevezés:");
		lblMegnevezes.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMegnevezes.setBounds(26, 45, 141, 27);
		frmOrabolt.getContentPane().add(lblMegnevezes);
		
		JLabel lblTipus = new JLabel("Típus:");
		lblTipus.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTipus.setBounds(26, 85, 141, 27);
		frmOrabolt.getContentPane().add(lblTipus);
		
		JLabel lblAr = new JLabel("Ár (Ft):");
		lblAr.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAr.setBounds(26, 125, 141, 27);
		frmOrabolt.getContentPane().add(lblAr);
		
		JLabel lblVizallo = new JLabel("Vízálló:");
		lblVizallo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblVizallo.setBounds(26, 165, 141, 27);
		frmOrabolt.getContentPane().add(lblVizallo);
		
		textMegnevezes = new JTextField();
		textMegnevezes.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textMegnevezes.setBounds(177, 45, 170, 27);
		frmOrabolt.getContentPane().add(textMegnevezes);
		textMegnevezes.setColumns(10);
		
		cbVizallo = new JCheckBox("");
		cbVizallo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		cbVizallo.setBounds(194, 165, 93, 21);
		frmOrabolt.getContentPane().add(cbVizallo);
		
		JButton btnMentes = new JButton("Mentés");
		btnMentes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!textMegnevezes.getText().equals(null) && !textMegnevezes.getText().isEmpty()) {
					try {
						oraObj = ABKezelo.adatfelvitel(textMegnevezes.getText(), /*(OraTipus)cbTipus.getSelectedItem()*/ textTipus.getText(),
								Integer.parseInt(textAr.getText()), cbVizallo.isSelected());
						orak.add(oraObj);
						listModel = new DefaultListModel<>();
						listaHozzarendeleseModellhez();
						
					} catch (NumberFormatException e1) {
						JOptionPane.showMessageDialog(frmOrabolt, "Nem megfelelő számformátum!", "Hiba", JOptionPane.ERROR_MESSAGE);
					} catch (SQLException e1) {
						JOptionPane.showMessageDialog(frmOrabolt, "SQL hiba", "Hiba", JOptionPane.ERROR_MESSAGE);
					}
				}else {
					JOptionPane.showMessageDialog(frmOrabolt, "A megnevezés kitöltése kötelező!", "Hiba", JOptionPane.ERROR_MESSAGE);
				}
				
				
			}
		});
		btnMentes.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnMentes.setBounds(207, 222, 125, 39);
		frmOrabolt.getContentPane().add(btnMentes);
		
		JButton btnKilepes = new JButton("Kilépés");
		btnKilepes.setForeground(new Color(255, 0, 0));
		btnKilepes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmOrabolt.dispatchEvent(new WindowEvent(frmOrabolt, WindowEvent.WINDOW_CLOSING));
			}
		});
		btnKilepes.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnKilepes.setBounds(42, 361, 116, 53);
		frmOrabolt.getContentPane().add(btnKilepes);
		
		JLabel lblTermeklista = new JLabel("Terméklista:");
		lblTermeklista.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTermeklista.setBounds(447, 10, 141, 27);
		frmOrabolt.getContentPane().add(lblTermeklista);
		
		
		
		listTermekek = new JList<Object>();
		listTermekek.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String adatok= orak.get(listTermekek.getSelectedIndex()).toString();
				JOptionPane.showMessageDialog(frmOrabolt, "Az óra adatai:\n"+adatok, "Informácio", JOptionPane.INFORMATION_MESSAGE);
				
			}
		});
		listTermekek.setFont(new Font("Tahoma", Font.PLAIN, 15));
		listTermekek.setBounds(434, 45, 191, 293);
		frmOrabolt.getContentPane().add(listTermekek);
		
		textAr = new JTextField();
		textAr.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textAr.setColumns(10);
		textAr.setBounds(177, 131, 170, 27);
		frmOrabolt.getContentPane().add(textAr);
		
		textTipus = new JTextField();
		textTipus.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textTipus.setColumns(10);
		textTipus.setBounds(177, 91, 170, 27);
		frmOrabolt.getContentPane().add(textTipus);
	}

	private void listaHozzarendeleseModellhez() {
			
			for(Ora ora : orak) {
				listModel.addElement(ora.getMegnevezes());
				
			}
			listTermekek.setModel(listModel);
			
	}
}
