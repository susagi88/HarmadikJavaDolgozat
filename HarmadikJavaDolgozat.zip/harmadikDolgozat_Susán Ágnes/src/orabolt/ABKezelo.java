package orabolt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import orabolt.FelsorolasOsztaly.OraTipus;



public class ABKezelo {
	
	private static Connection kapcsolat;
	private static PreparedStatement sqlUtasitas;
	private static Ora oraObj;
	
	private ABKezelo() {
		
	}

	public static void csatlakozas() throws SQLException {
		try {
			
			String connectionString = "jdbc:mysql://localhost:3306/orabolt?autoReconnect=true&useSSL=false";
			
			kapcsolat= DriverManager.getConnection(connectionString, "root", "Cickany88");
			
		} catch (Exception e) {
			throw new SQLException("A csatlakozás sikertelen! "+e.getMessage());
		}
		
	}
	
	public static void kapcsolatBontas() throws SQLException {
		try {
			
			kapcsolat.close();
			
		}catch(Exception e) {
			throw new SQLException("A kapcsolat bontása sikertelen!");
		}
	}
	
	public static List<Ora> orakBeolvasasa() throws SQLException {
		
		try {
			
			List<Ora> orak = new ArrayList<Ora>();
			sqlUtasitas=kapcsolat.prepareStatement("SELECT * FROM ora");
			
			ResultSet res = sqlUtasitas.executeQuery();
			while(res.next()) {
				orak.add(new Ora(
						res.getString("megnevezes"),
						//OraTipus.valueOf(res.getString("tipus")),
						res.getString("tipus"),
						res.getInt("ar"),
						res.getBoolean("vizallo")
						));
			}
			
			res.close();
			
			
			return orak;
			
			
		} catch (Exception e) {
			
			throw new SQLException("Adatbázisból beolvasás sikertelen");
			
		}
		
	}

	public static Ora adatfelvitel(String megnevezes, /*OraTipus tipus*/String tipus, int ar, boolean vizallo) throws SQLException {
		
		
		try {
			oraObj= new Ora(megnevezes, tipus, ar, vizallo);
			
			sqlUtasitas = kapcsolat.prepareStatement("INSERT INTO ora VALUES (?,?,?,?)");
			sqlUtasitas.setString(1, megnevezes);
			sqlUtasitas.setString(2, String.valueOf(oraObj.getTipus()));
			sqlUtasitas.setInt(3, ar);
			sqlUtasitas.setBoolean(4, vizallo);
			
			sqlUtasitas.executeUpdate();
			
			sqlUtasitas.clearParameters();
			return oraObj;
			
			
		} catch (Exception e) {
			
				throw new SQLException("A felvitel sikertelen!"+e.getMessage());
		}
			
	}

}
