package orabolt;

import orabolt.FelsorolasOsztaly.OraTipus;

public class Ora {
	
	String megnevezes;
	//OraTipus tipus;
	String tipus;
	int ar;
	boolean vizallo;
	
	
	/*public Ora(String megnevezes, OraTipus tipus, int ar, boolean vizallo) {
		setMegnevezes(megnevezes);
		this.tipus = tipus;
		setAr(ar);;
		this.vizallo = vizallo;
	}*/
	
	public Ora(String megnevezes, String tipus, int ar, boolean vizallo) {
		setMegnevezes(megnevezes);
		this.tipus = tipus;
		setAr(ar);;
		this.vizallo = vizallo;
	}

	

	public String getMegnevezes() {
		return megnevezes;
	}



	/*public OraTipus getTipus() {
		return tipus;
	}*/

	public String getTipus() {
		return tipus;
	}


	public int getAr() {
		return ar;
	}



	public boolean isVizallo() {
		return vizallo;
	}



	public void setMegnevezes(String megnevezes) {
		if(megnevezes!=null && !megnevezes.isEmpty()) {
			this.megnevezes = megnevezes;
		}
		else {
			throw new IllegalArgumentException("A megnevezés kitöltése kötelező");
		}
	}


	public void setAr(int ar) {
		if(ar>=0) {
			this.ar = ar;
		}
		else {
			throw new IllegalArgumentException("Az ár nem lehet negatív szám!");
		}
	}



	@Override
	public String toString() {
		return megnevezes + " " + tipus + " " + ar + " ft " + (vizallo?"vizálló":"nem vízálló");
	}
	
	
	
	
	
	

}
